```
$ gdal_rasterize -a key -tr 0.02 0.02 -ot byte -l middle_east middle_east.shp middle_east.tif
```