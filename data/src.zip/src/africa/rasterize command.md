```
$ gdal_rasterize -a key -tr 0.045 0.045 -ot byte -l africa africa.shp africa.tif
```