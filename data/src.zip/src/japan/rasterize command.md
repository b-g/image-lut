```
$ gdal_rasterize -a key -tr 0.02 0.02 -ot byte -l japan japan.shp japan.tif
```
